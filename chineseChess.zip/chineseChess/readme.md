
找到该目录下release目录下的.exe程序

qt cmd

windeployqt  exe程序
