﻿
#include "ChooseMainWindow.h"

#include <QApplication>
#include "ChessBoard.h"
#include <QMessageBox>

#pragma  execution_character_set("utf-8")

ChooseMainWindow::ChooseMainWindow(int nChooseGame, QWidget *parent) : QWidget(parent)
{
    m_nChooseGame = nChooseGame;

    if(0 == m_nChooseGame)
    {
        /*游戏方式一: 自己和自己下棋【同一台PC机器】*/
        m_p1 = new ChessBoard(this);
        m_p1->setWindowTitle("玩家自己对战");
        //m_p1->setAttribute(Qt::WA_ShowModal, true);
        m_p1->exec();

    }
    else if(1 == m_nChooseGame)
    {
    }
    else if(2 == m_nChooseGame)
    {

    }
    else
    {

    }


}

ChooseMainWindow::~ChooseMainWindow()
{

    if(0 == m_nChooseGame)
    {
        delete m_p1;
    }
    else if(1 == m_nChooseGame)
    {
    }
    else if(2 == m_nChooseGame)
    {
    }
    else
    {

    }
}

