﻿#include <QApplication>
#include "SelectGameMode.h"
#include "ChooseMainWindow.h"

#pragma  execution_character_set("utf-8")

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    SelectGameMode dlg;
    dlg.setWindowTitle("选择游戏方式");
    dlg.setFixedSize(200,120);
    dlg.setWindowIcon(QIcon(":/images/qaz.ico"));
    if(dlg.exec() != QDialog::Accepted)
    {
        return 0;
    }
     ChooseMainWindow pWnd(dlg.m_nSelect);
     dlg.exec();

    return a.exec();
}
