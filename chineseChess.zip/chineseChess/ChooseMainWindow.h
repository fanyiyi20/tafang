﻿
#ifndef CHOOSEMAINWINDOW_H
#define CHOOSEMAINWINDOW_H

#include <QWidget>
#include "ChessBoard.h"


class ChooseMainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit ChooseMainWindow(int nChooseGame, QWidget *parent = 0);
    ~ChooseMainWindow();


    int m_nChooseGame;

    ChessBoard* m_p1;
signals:

public slots:
};

#endif // CHOOSEMAINWINDOW_H
