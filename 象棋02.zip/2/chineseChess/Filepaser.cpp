﻿#include "Filepaser.h"

#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;

CFilePaser::CFilePaser()
{

}

void CFilePaser::writeFile(QMap<QString, QString> mapData)
{
    std::ofstream outFile;
    outFile.open(FILEPATH, std::ios::trunc);  //覆盖原文件内容

    for (QMap<QString, QString>::iterator it = mapData.begin(); it != mapData.end(); it++)
    {
        outFile << it.key().toStdString() << " " << it.value().toStdString() << std::endl;
    }

    outFile.close();
}

QMap<QString, QString> CFilePaser::readFile(const QString &fileName)
{
    QMap<QString, QString> mapResult;

    std::ifstream outFile;
    outFile.open(FILEPATH);
    if (!outFile.is_open())
    {
        return mapResult;
    }

    char line[1024] = { 0 };

    while (!outFile.eof())
    {
        outFile.getline(line, sizeof(line));
        if (line == "\n")
            continue;
        if (sizeof(line) == 0)
            continue;

        //student *temp;
        std::stringstream  data(line);
        std::string userName, passwd;
        data >> userName;
        data >> passwd;

        mapResult.insert(QString::fromStdString(userName), QString::fromStdString(passwd));
    }
    outFile.close();

    return mapResult;
}
