﻿#include "Register.h"
#include <QMessageBox>
#include "ui_register.h"

#pragma  execution_character_set("utf-8")


CRegister::CRegister(QMap<QString, QString> mapUser, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CRegister),
    m_user(""),
    m_passwd("")
{
    ui->setupUi(this);
    m_mapUser = mapUser;

    setWindowTitle("注册");
}

CRegister::~CRegister()
{
    delete ui;
}

void CRegister::on_btnOK_clicked()
{
    m_user = ui->lineEdit->text();
    m_passwd = ui->lineEdit_2->text();
    QString pwd = ui->lineEdit_3->text();

    if (m_user.isEmpty() || m_passwd.isEmpty() || pwd.isEmpty())
    {
        QMessageBox::warning(NULL, "Tips", "请输入完整",  QMessageBox::Ok);
        return;
    }

    if (m_passwd != pwd)
    {
        QMessageBox::warning(NULL, "Tips", "两次密码输入不一致，请重输",  QMessageBox::Ok);
        ui->lineEdit_2->clear();
        ui->lineEdit_3->clear();
        return;
    }

    if (m_mapUser.contains(m_user))
    {
        QMessageBox::warning(NULL, "Tips", "该用户已存在，请修改",  QMessageBox::Ok);
        return;
    }

    QMessageBox::information(NULL, "Tips", "注册成功，返回登录",  QMessageBox::Ok);
    accept();
}

void CRegister::on_btnCancel_clicked()
{

}

