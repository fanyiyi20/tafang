﻿#ifndef CFILEPASER_H
#define CFILEPASER_H

#include <QMap>

#define FILEPATH "./usrPasswd.text"

class CFilePaser
{
public:
    CFilePaser();

    void writeFile(QMap<QString, QString> mapData);
    QMap<QString, QString> readFile(const QString &fileName);
};

#endif // CFILEPASER_H
