/********************************************************************************
** Form generated from reading UI file 'AboutAuthor.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUTAUTHOR_H
#define UI_ABOUTAUTHOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextBrowser>

QT_BEGIN_NAMESPACE

class Ui_AboutAuthor
{
public:
    QDialogButtonBox *buttonBox;
    QTextBrowser *textBrowser;
    QLabel *label_5;

    void setupUi(QDialog *AboutAuthor)
    {
        if (AboutAuthor->objectName().isEmpty())
            AboutAuthor->setObjectName(QString::fromUtf8("AboutAuthor"));
        AboutAuthor->resize(631, 491);
        AboutAuthor->setFocusPolicy(Qt::NoFocus);
        AboutAuthor->setAcceptDrops(false);
        AboutAuthor->setToolTipDuration(0);
        AboutAuthor->setLayoutDirection(Qt::RightToLeft);
        buttonBox = new QDialogButtonBox(AboutAuthor);
        buttonBox->setObjectName(QString::fromUtf8("buttonBox"));
        buttonBox->setGeometry(QRect(430, 430, 151, 31));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        textBrowser = new QTextBrowser(AboutAuthor);
        textBrowser->setObjectName(QString::fromUtf8("textBrowser"));
        textBrowser->setGeometry(QRect(20, 10, 391, 461));
        textBrowser->setStyleSheet(QString::fromUtf8("background-image: url(:/images/5abc.png);\n"
"font: 9pt \"\345\215\216\346\226\207\346\245\267\344\275\223\";"));
        label_5 = new QLabel(AboutAuthor);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(0, 0, 621, 491));
        label_5->setPixmap(QPixmap(QString::fromUtf8(":/images/5abc.png")));
        label_5->setScaledContents(true);
        label_5->raise();
        buttonBox->raise();
        textBrowser->raise();

        retranslateUi(AboutAuthor);
        QObject::connect(buttonBox, SIGNAL(accepted()), AboutAuthor, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), AboutAuthor, SLOT(reject()));

        QMetaObject::connectSlotsByName(AboutAuthor);
    } // setupUi

    void retranslateUi(QDialog *AboutAuthor)
    {
        AboutAuthor->setWindowTitle(QApplication::translate("AboutAuthor", "Dialog", nullptr));
        textBrowser->setHtml(QApplication::translate("AboutAuthor", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'\345\215\216\346\226\207\346\245\267\344\275\223'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:12pt;\">\344\270\255\345\233\275\350\261\241\346\243\213:</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:12pt;\">  1. \346\224\257\346\214\201\347\275\221\347\273\234\345\257\271\346\210\230</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\""
                        " font-family:'SimSun'; font-size:12pt;\">  2. \346\224\257\346\214\201\344\272\272\346\234\272\345\257\271\346\210\230</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:12pt;\">  3. \346\224\257\346\214\201\347\216\251\345\256\266\350\207\252\345\267\261\345\257\271\346\210\230</span></p>\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'SimSun'; font-size:12pt;\"><br /></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:14pt;\">\350\201\224\347\263\273\344\275\234\350\200\205:</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'S"
                        "imSun'; font-size:14pt;\">\345\276\256\344\277\241: xxxx                                                                                                                             \351\202\256\347\256\261: xxxxx@163.com</span></p>\n"
"<p style=\" margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'SimSun'; font-size:14pt;\">\345\215\232\345\256\242: https://blog.csdn.net/xxxxx</span></p></body></html>", nullptr));
        label_5->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AboutAuthor: public Ui_AboutAuthor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUTAUTHOR_H
