/********************************************************************************
** Form generated from reading UI file 'Changepasswd.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGEPASSWD_H
#define UI_CHANGEPASSWD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CChangePasswd
{
public:
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *usrLineEdit;
    QLabel *label_2;
    QLineEdit *oldPasswdLineEdit;
    QLabel *label_3;
    QLineEdit *newPasswdLineEdit;
    QPushButton *btnOK;
    QPushButton *btnCancel;

    void setupUi(QDialog *CChangePasswd)
    {
        if (CChangePasswd->objectName().isEmpty())
            CChangePasswd->setObjectName(QString::fromUtf8("CChangePasswd"));
        CChangePasswd->resize(313, 184);
        formLayoutWidget = new QWidget(CChangePasswd);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(40, 30, 241, 80));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        usrLineEdit = new QLineEdit(formLayoutWidget);
        usrLineEdit->setObjectName(QString::fromUtf8("usrLineEdit"));

        formLayout->setWidget(0, QFormLayout::FieldRole, usrLineEdit);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        oldPasswdLineEdit = new QLineEdit(formLayoutWidget);
        oldPasswdLineEdit->setObjectName(QString::fromUtf8("oldPasswdLineEdit"));

        formLayout->setWidget(1, QFormLayout::FieldRole, oldPasswdLineEdit);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        newPasswdLineEdit = new QLineEdit(formLayoutWidget);
        newPasswdLineEdit->setObjectName(QString::fromUtf8("newPasswdLineEdit"));

        formLayout->setWidget(2, QFormLayout::FieldRole, newPasswdLineEdit);

        btnOK = new QPushButton(CChangePasswd);
        btnOK->setObjectName(QString::fromUtf8("btnOK"));
        btnOK->setGeometry(QRect(50, 130, 75, 23));
        btnCancel = new QPushButton(CChangePasswd);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));
        btnCancel->setGeometry(QRect(170, 130, 75, 23));

        retranslateUi(CChangePasswd);

        QMetaObject::connectSlotsByName(CChangePasswd);
    } // setupUi

    void retranslateUi(QDialog *CChangePasswd)
    {
        CChangePasswd->setWindowTitle(QApplication::translate("CChangePasswd", "Dialog", nullptr));
        label->setText(QApplication::translate("CChangePasswd", "\350\257\267\350\276\223\345\205\245\350\264\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("CChangePasswd", "\350\257\267\350\276\223\345\205\245\345\216\237\345\257\206\347\240\201", nullptr));
        label_3->setText(QApplication::translate("CChangePasswd", "\350\257\267\350\276\223\345\205\245\346\226\260\345\257\206\347\240\201", nullptr));
        btnOK->setText(QApplication::translate("CChangePasswd", "\347\241\256 \350\256\244", nullptr));
        btnCancel->setText(QApplication::translate("CChangePasswd", "\345\217\226 \346\266\210", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CChangePasswd: public Ui_CChangePasswd {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGEPASSWD_H
