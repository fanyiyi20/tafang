/********************************************************************************
** Form generated from reading UI file 'Register.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REGISTER_H
#define UI_REGISTER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_CRegister
{
public:
    QWidget *formLayoutWidget;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QLineEdit *lineEdit_3;
    QLabel *label_3;
    QPushButton *btnOK;
    QPushButton *btnCancel;

    void setupUi(QDialog *CRegister)
    {
        if (CRegister->objectName().isEmpty())
            CRegister->setObjectName(QString::fromUtf8("CRegister"));
        CRegister->resize(293, 183);
        formLayoutWidget = new QWidget(CRegister);
        formLayoutWidget->setObjectName(QString::fromUtf8("formLayoutWidget"));
        formLayoutWidget->setGeometry(QRect(30, 20, 231, 74));
        formLayout = new QFormLayout(formLayoutWidget);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        formLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(formLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lineEdit = new QLineEdit(formLayoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        formLayout->setWidget(0, QFormLayout::FieldRole, lineEdit);

        label_2 = new QLabel(formLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        lineEdit_2 = new QLineEdit(formLayoutWidget);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));

        formLayout->setWidget(1, QFormLayout::FieldRole, lineEdit_2);

        lineEdit_3 = new QLineEdit(formLayoutWidget);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));

        formLayout->setWidget(2, QFormLayout::FieldRole, lineEdit_3);

        label_3 = new QLabel(formLayoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        formLayout->setWidget(2, QFormLayout::LabelRole, label_3);

        btnOK = new QPushButton(CRegister);
        btnOK->setObjectName(QString::fromUtf8("btnOK"));
        btnOK->setGeometry(QRect(50, 120, 75, 23));
        btnCancel = new QPushButton(CRegister);
        btnCancel->setObjectName(QString::fromUtf8("btnCancel"));
        btnCancel->setGeometry(QRect(150, 120, 75, 23));

        retranslateUi(CRegister);

        QMetaObject::connectSlotsByName(CRegister);
    } // setupUi

    void retranslateUi(QDialog *CRegister)
    {
        CRegister->setWindowTitle(QApplication::translate("CRegister", "Dialog", nullptr));
        label->setText(QApplication::translate("CRegister", "\350\257\267\350\276\223\345\205\245\350\264\246\345\217\267", nullptr));
        label_2->setText(QApplication::translate("CRegister", "\350\257\267\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        label_3->setText(QApplication::translate("CRegister", "\350\257\267\345\206\215\346\254\241\350\276\223\345\205\245\345\257\206\347\240\201", nullptr));
        btnOK->setText(QApplication::translate("CRegister", "\347\241\256 \350\256\244", nullptr));
        btnCancel->setText(QApplication::translate("CRegister", "\345\217\226 \346\266\210", nullptr));
    } // retranslateUi

};

namespace Ui {
    class CRegister: public Ui_CRegister {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REGISTER_H
