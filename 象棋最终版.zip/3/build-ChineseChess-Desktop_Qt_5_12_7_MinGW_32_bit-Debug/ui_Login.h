/********************************************************************************
** Form generated from reading UI file 'Login.ui'
**
** Created by: Qt User Interface Compiler version 5.12.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_H
#define UI_LOGIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LoginClass
{
public:
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QPushButton *btnRegister;
    QPushButton *btnLogin;
    QLabel *label_2;
    QPushButton *btnClose;
    QPushButton *btnMin;
    QPushButton *btnSetting;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QComboBox *accountBox;
    QLineEdit *passswdBox;
    QPushButton *btnGetPasswd;
    QPushButton *btnChangePwd;

    void setupUi(QDialog *LoginClass)
    {
        if (LoginClass->objectName().isEmpty())
            LoginClass->setObjectName(QString::fromUtf8("LoginClass"));
        LoginClass->resize(411, 291);
        LoginClass->setStyleSheet(QString::fromUtf8("QDialog{\n"
" border: 1px solid white;\n"
"}"));
        checkBox = new QCheckBox(LoginClass);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(81, 274, 71, 16));
        checkBox_2 = new QCheckBox(LoginClass);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(163, 274, 71, 16));
        btnRegister = new QPushButton(LoginClass);
        btnRegister->setObjectName(QString::fromUtf8("btnRegister"));
        btnRegister->setGeometry(QRect(90, 190, 75, 23));
        btnRegister->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"	color:rgb(14, 115, 95);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color:rgb(14, 115, 95);\n"
"    border-color: #444444;\n"
"	color:yellow;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        btnLogin = new QPushButton(LoginClass);
        btnLogin->setObjectName(QString::fromUtf8("btnLogin"));
        btnLogin->setGeometry(QRect(90, 220, 231, 41));
        btnLogin->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: 0px solid white;\n"
"    background-color:rgb(34, 174, 250);\n"
"	color:white;\n"
"	border-radius:4px;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color:rgb(70, 100, 15);\n"
"    border-color: #444444;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(14, 115, 95);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        label_2 = new QLabel(LoginClass);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(0, 0, 411, 81));
        label_2->setStyleSheet(QString::fromUtf8("QLabel {\n"
"    border: 0px solid white;\n"
"    background-color:rgb(110, 105, 255);\n"
"	color:white;\n"
"}"));
        btnClose = new QPushButton(LoginClass);
        btnClose->setObjectName(QString::fromUtf8("btnClose"));
        btnClose->setGeometry(QRect(380, 0, 31, 31));
        btnClose->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: 0px solid white;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(0, 255, 127);\n"
"    border-color: #444444;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        btnMin = new QPushButton(LoginClass);
        btnMin->setObjectName(QString::fromUtf8("btnMin"));
        btnMin->setGeometry(QRect(350, 0, 31, 31));
        btnMin->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: 0px solid white;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(0, 255, 127);\n"
"    border-color: #444444;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        btnSetting = new QPushButton(LoginClass);
        btnSetting->setObjectName(QString::fromUtf8("btnSetting"));
        btnSetting->setGeometry(QRect(320, 0, 31, 31));
        btnSetting->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: 0px solid white;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: rgb(0, 255, 127);\n"
"    border-color: #444444;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        layoutWidget = new QWidget(LoginClass);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 120, 231, 60));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        accountBox = new QComboBox(layoutWidget);
        accountBox->setObjectName(QString::fromUtf8("accountBox"));
        accountBox->setStyleSheet(QString::fromUtf8("QComboBox {\n"
"    border-left: none;\n"
" 	border-top: none;\n"
" 	border-right:none;\n"
"	border-bottom: 1px solid gray;\n"
"	height:25px;\n"
"	color:rgb(14, 115, 95);\n"
"}\n"
" \n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 15px;\n"
" \n"
"    border-left-width: 0px;\n"
"    border-left-color: darkgray;\n"
"    border-left-style: solid; /* just a single line */\n"
"    border-top-right-radius: 0px; /* same radius as the QComboBox */\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
" \n"
"QComboBox::down-arrow {\n"
"    image: url(:Login/Resources/downarrow.png);\n"
"	height:30px;\n"
"	width:20px;\n"
"}\n"
" \n"
"QComboBox::down-arrow:on { /* shift the arrow when popup is open */\n"
"    top: 1px;\n"
"    left: 1px;\n"
"}"));
        accountBox->setEditable(true);

        verticalLayout->addWidget(accountBox);

        passswdBox = new QLineEdit(layoutWidget);
        passswdBox->setObjectName(QString::fromUtf8("passswdBox"));
        passswdBox->setStyleSheet(QString::fromUtf8("QLineEdit {\n"
"    border-left: none;\n"
" 	border-top: none;\n"
" 	border-right:none;\n"
"	border-bottom: 1px solid gray;\n"
"	height:25px;\n"
"	color:rgb(14, 115, 95);\n"
"}\n"
" \n"
"QComboBox::drop-down {\n"
"    subcontrol-origin: padding;\n"
"    subcontrol-position: top right;\n"
"    width: 15px;\n"
" \n"
"    border-left-width: 0px;\n"
"    border-left-color: darkgray;\n"
"    border-left-style: solid; /* just a single line */\n"
"    border-top-right-radius: 0px; /* same radius as the QComboBox */\n"
"    border-bottom-right-radius: 0px;\n"
"}\n"
" \n"
"\n"
" \n"
""));

        verticalLayout->addWidget(passswdBox);

        btnGetPasswd = new QPushButton(LoginClass);
        btnGetPasswd->setObjectName(QString::fromUtf8("btnGetPasswd"));
        btnGetPasswd->setGeometry(QRect(260, 270, 48, 21));
        btnGetPasswd->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"	color:rgb(14, 115, 95);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color:rgb(14, 115, 95);\n"
"    border-color: #444444;\n"
"	color:yellow;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));
        btnChangePwd = new QPushButton(LoginClass);
        btnChangePwd->setObjectName(QString::fromUtf8("btnChangePwd"));
        btnChangePwd->setGeometry(QRect(240, 190, 75, 23));
        btnChangePwd->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"	color:rgb(14, 115, 95);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color:rgb(14, 115, 95);\n"
"    border-color: #444444;\n"
"	color:yellow;\n"
"}\n"
" \n"
"QPushButton:pressed {\n"
"    background-color:rgb(85, 170, 127);\n"
"    border-color: #333333;\n"
"    color: yellow;\n"
"}"));

        retranslateUi(LoginClass);

        QMetaObject::connectSlotsByName(LoginClass);
    } // setupUi

    void retranslateUi(QDialog *LoginClass)
    {
        LoginClass->setWindowTitle(QApplication::translate("LoginClass", "Login", nullptr));
        checkBox->setText(QApplication::translate("LoginClass", "\350\207\252\345\212\250\347\231\273\345\275\225", nullptr));
        checkBox_2->setText(QApplication::translate("LoginClass", "\350\256\260\344\275\217\345\257\206\347\240\201", nullptr));
        btnRegister->setText(QApplication::translate("LoginClass", "\346\263\250\345\206\214\350\264\246\345\217\267", nullptr));
        btnLogin->setText(QApplication::translate("LoginClass", "\347\231\273 \345\275\225", nullptr));
        label_2->setText(QString());
        btnClose->setText(QString());
        btnMin->setText(QString());
        btnSetting->setText(QString());
        btnGetPasswd->setText(QApplication::translate("LoginClass", "\346\211\276\345\233\236\345\257\206\347\240\201", nullptr));
        btnChangePwd->setText(QApplication::translate("LoginClass", "\344\277\256\346\224\271\345\257\206\347\240\201", nullptr));
    } // retranslateUi

};

namespace Ui {
    class LoginClass: public Ui_LoginClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_H
