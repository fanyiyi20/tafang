﻿#include "Changepasswd.h"
#include "ui_Changepasswd.h"

#include <QMessageBox>

#pragma  execution_character_set("utf-8")

CChangePasswd::CChangePasswd(QMap<QString, QString> mapUser, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CChangePasswd)
{
    ui->setupUi(this);

    m_mapUsers = mapUser;
    setWindowTitle("修改密码");
}

CChangePasswd::~CChangePasswd()
{
    delete ui;
}

void CChangePasswd::on_btnOK_clicked()
{
    QString userName = ui->usrLineEdit->text();
    QString oldPwd = ui->oldPasswdLineEdit->text();
    QString newPwd = ui->newPasswdLineEdit->text();

    if (userName.isEmpty() || oldPwd.isEmpty() || newPwd.isEmpty())
    {
        QMessageBox::warning(NULL, "Tips", "请输入完整",  QMessageBox::Ok);
        return;
    }

    if (m_mapUsers.contains(userName))
    {
        if (m_mapUsers[userName] == oldPwd)
        {
            m_mapUsers[userName] = newPwd;
            QMessageBox::warning(NULL, "Tips", "修改成功,返回登录",  QMessageBox::Ok);
            accept();
        }
        else
        {
            QMessageBox::warning(NULL, "Tips", "原密码输入错误，请确认",  QMessageBox::Ok);
        }
    }
    else
    {
        QMessageBox::warning(NULL, "Tips", "该用户不存在，请确认",  QMessageBox::Ok);
    }
}

void CChangePasswd::on_btnCancel_clicked()
{

}
