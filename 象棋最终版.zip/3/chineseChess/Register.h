﻿#ifndef REGISTER_H
#define REGISTER_H

#include <QDialog>
#include <QMap>

namespace Ui {
class CRegister;
}

class CRegister : public QDialog
{
    Q_OBJECT

public:
    explicit CRegister(QMap<QString, QString> mapUser, QWidget *parent = nullptr);
    ~CRegister();

    QString getUserName() { return m_user; }
    QString getPassWd() { return m_passwd; }
public slots:
    void on_btnOK_clicked();
    void on_btnCancel_clicked();

private:
    Ui::CRegister *ui;

    QString m_user;
    QString m_passwd;
    QMap<QString, QString> m_mapUser;
};

#endif // REGISTER_H
