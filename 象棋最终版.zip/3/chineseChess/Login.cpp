﻿#include "Login.h"
#include <QIcon>
#include <QAction>
#include <QPixmap>
#include <QMouseEvent>
#include <QLineEdit>
#include <dwmapi.h>
#include <windowsx.h>

#include "SelectGameMode.h"
#include "ChooseMainWindow.h"
#include "Register.h"
#include "Changepasswd.h"
#include "Filepaser.h"

#pragma  execution_character_set("utf-8")

Login::Login(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);

	setMouseTracking(true);
	setPalette(QPalette(Qt::white));

    this->setWindowFlags(Qt::FramelessWindowHint);  //无边框，但在任务栏显示标题
    /*  论如何实现无边框有阴影的窗口 */

    setWindowIcon(QIcon(":/images/ch.png"));

    //最小化，关闭按钮
	ui.btnMin->setIcon(style()->standardIcon(QStyle::SP_TitleBarMinButton));
	ui.btnClose->setIcon(style()->standardIcon(QStyle::SP_TitleBarCloseButton));
    ui.btnSetting->setIcon(QIcon(":/images/setting.png"));

	
    ui.accountBox->lineEdit()->setPlaceholderText("请 输 入 账 号");
	QAction *userAction = new QAction(ui.accountBox->lineEdit());
    userAction->setIcon(QIcon(":/images/user.png"));
    ui.accountBox->lineEdit()->addAction(userAction, QLineEdit::LeadingPosition);	//输入框左侧添加图标


    ui.passswdBox->setPlaceholderText("请 输 入 密 码");
	QAction * uAction = new QAction(ui.passswdBox);
    uAction->setIcon(QIcon(":/images/passwd.png"));
    ui.passswdBox->addAction(uAction, QLineEdit::LeadingPosition);	//输入框左侧添加图标

    //hide
    ui.checkBox->setVisible(false);
    ui.checkBox_2->setVisible(false);
    ui.btnGetPasswd->setVisible(false);

    //初始化
    CFilePaser filePaser;
    m_mapUser = filePaser.readFile(FILEPATH);
}

bool Login::checkUsrNameAndPasswd(const QString &usrName, const QString &passwd)
{
    for (QMap<QString, QString>::iterator it = m_mapUser.begin(); it != m_mapUser.end(); it++)
    {
        if (it.key() == usrName && it.value() == passwd)
            return true;
    }

    return false;
}

void Login::mousePressEvent(QMouseEvent * event)
{
	if (event->button() == Qt::LeftButton)
	{
		m_moving = true;
        m_lastPos = event->globalPos() - pos();    //记录下鼠标相对于窗口的位置
	}
	return QDialog::mousePressEvent(event);
}

void Login::mouseMoveEvent(QMouseEvent * event)
{
	if (m_moving && (event->buttons() && Qt::LeftButton) &&
		(event->globalPos() - m_lastPos).manhattanLength() >
		QApplication::startDragDistance())
	{
		move(event->globalPos() - m_lastPos);
		m_lastPos = event->globalPos() - pos();
	}

	return QDialog::mouseMoveEvent(event);
}

void Login::mouseReleaseEvent(QMouseEvent * event)
{
	m_moving = false;
}

void Login::on_btnClose_clicked()
{
	this->close();
}

void Login::on_btnMin_clicked()
{
    this->showMinimized();
}

void Login::on_btnLogin_clicked()
{
    QString usrName = ui.accountBox->currentText();
    QString passwd = ui.passswdBox->text();

    if (usrName.isEmpty() || passwd.isEmpty())
    {
        QMessageBox::warning(NULL, "Tips", "请输入账号和密码", QMessageBox::Ok);
        return;
    }

    bool ret = checkUsrNameAndPasswd(usrName, passwd);
    if (ret)
    {
        this->close();

        SelectGameMode dlg;
        dlg.setWindowTitle("选择游戏方式");
        dlg.setFixedSize(200,120);
        dlg.setWindowIcon(QIcon(":/images/qaz.ico"));
        if(dlg.exec() != QDialog::Accepted)
        {
            return;
        }
         ChooseMainWindow pWnd(dlg.m_nSelect);
         //ChooseMainWindow *pWnd  = new ChooseMainWindow(dlg.m_nSelect);
    }
    else
    {
        QMessageBox::warning(NULL, "Tips", "账号或密码错误，请确认", QMessageBox::Ok);
    }
}

void Login::on_btnChangePwd_clicked()       //修改密码
{
    CChangePasswd ChangePasswdDlg(m_mapUser);
    if (ChangePasswdDlg.exec() == QDialog::Accepted)
    {
        m_mapUser = ChangePasswdDlg.getMapUsers();

        CFilePaser filePaser;
        filePaser.writeFile(m_mapUser);
    }
}

void Login::on_btnRegister_clicked()        //注册
{
    CRegister registerDlg(m_mapUser);
    if (registerDlg.exec() == QDialog::Accepted)
    {
        QString usrName = registerDlg.getUserName();
        QString pwd = registerDlg.getPassWd();
        m_mapUser.insert(usrName, pwd);

        CFilePaser filePaser;
        filePaser.writeFile(m_mapUser);
    }
}
