﻿#pragma once

#include <QtWidgets/QDialog>
#include "ui_Login.h"

class Login : public QDialog
{
	Q_OBJECT

public:
	Login(QWidget *parent = Q_NULLPTR);

    bool checkUsrNameAndPasswd(const QString &usrName, const QString &passwd);
protected:
	void mousePressEvent(QMouseEvent * event);
	void mouseMoveEvent(QMouseEvent * event);
	void mouseReleaseEvent(QMouseEvent * event);
public slots:
    void on_btnClose_clicked();	//关闭登录页
	void on_btnMin_clicked();	//最小化
    void on_btnLogin_clicked(); //登录按钮
    void on_btnChangePwd_clicked(); //修改密码
    void on_btnRegister_clicked();  //注册

private:
	Ui::LoginClass ui;

	bool m_moving = false;          //表示窗口是否在鼠标操作下移动
	QPoint m_lastPos;               //上一次鼠标位置

    QMap<QString, QString> m_mapUser;
};
