﻿#ifndef CHANGEPASSWD_H
#define CHANGEPASSWD_H

#include <QDialog>
#include <QMap>

namespace Ui {
class CChangePasswd;
}

class CChangePasswd : public QDialog
{
    Q_OBJECT

public:
    explicit CChangePasswd(QMap<QString, QString> mapUser, QWidget *parent = nullptr);
    ~CChangePasswd();

    QMap<QString, QString> getMapUsers() { return m_mapUsers; }

public slots:
    void on_btnOK_clicked();
    void on_btnCancel_clicked();

private:
    Ui::CChangePasswd *ui;

    QMap<QString, QString> m_mapUsers;
};

#endif // CHANGEPASSWD_H
